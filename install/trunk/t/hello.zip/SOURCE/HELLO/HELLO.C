/* hello.c */

/* The classic "Hello, world!" program. */

/*
  This is a demo/test program, so the FreeDOS Install program has
  something to work with. Released in the public domain.
  - Jim Hall <jhall@freedos.org>
*/

#include <stdio.h>
#include <stdlib.h>

int
main (void)
{
  printf ("Hello, world!\n");
  exit (0);
}
